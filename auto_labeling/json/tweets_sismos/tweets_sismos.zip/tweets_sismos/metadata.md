# Dumps de tweets en torno a sismos
Eventos sismologicos grado +6 ocurridos en los meses Jun, Jul y Ago del 2016
Cada archivo es una coleccion de Tweets ocurridos en una ventana de 1 hora en torno a un evento sismologico (1 hora antes & 1 hora despu�s)

* Jun 2016 1: 2016-06-07 10:51:37 Magnitud: 6.3 Mexico
* Jun 2016 2: 2016-06-10 03:25:22 Magnitud: 6.1 Nicaragua
* Jul 2016 1: 2016-07-11 02:11:04 Magnitud: 6.3 Ecuador
* Jul 2016 2: 2016-07-25 17:26:50 Magnitud: 6.1 Chile
* Ago 2016 1: 2016-08-04 14:15:12 Magnitud: 6.2 Argentina
* Ago 2016 2: 2016-08-18 18:09:43 Magnitud: 6.0 Sur-Este del Oceano Pacifico